#include <deque>
#include <iostream>
#include "Token.h"
class Test {
    public:
        void createSubtree(std::deque<Token *> &yolo) {
            int i = std::stoi("145", nullptr, 10);
            std::cout << i << std::endl;

        }
};